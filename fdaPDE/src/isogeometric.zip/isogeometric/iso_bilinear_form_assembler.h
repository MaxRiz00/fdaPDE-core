// This file is part of fdaPDE, a C++ library for physics-informed
// spatial and functional data analysis.
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

#ifndef __FDAPDE_ISO_BILINEAR_FORM_ASSEMBLER_H__
#define __FDAPDE_ISO_BILINEAR_FORM_ASSEMBLER_H__

#include "header_check.h"

namespace fdapde {
namespace internals {

template<typename IsoMesh_, typename Form_, int Options_, typename... Quadrature_>
class iso_bilinear_form_assembly_loop :
    public iso_assembler_base<IsoMesh_, Form_, Options_, Quadrature_...>,
    public assembly_xpr_base<iso_bilinear_form_assembly_loop<IsoMesh_, Form_, Options_, Quadrature_...>> {
    // detect trial and test spaces from bilinear form
    using TestSpace = test_space_t<Form_>;
    using TrialSpace = trial_space_t<Form_>;
    static_assert(TestSpace::local_dim == TrialSpace::local_dim && TestSpace::embed_dim == TrialSpace::embed_dim);
    static constexpr bool is_galerkin = std::is_same_v<TestSpace, TrialSpace>;
    static constexpr bool is_petrov_galerkin = !is_galerkin;
    using Base = iso_assembler_base<IsoMesh_, Form_, Options_, Quadrature_...>;
    using Form = typename Base::Form;
    
    using DofHandlerType = typename Base::DofHandlerType;
    using discretization_category = typename TestSpace::discretization_category;

    fdapde_static_assert(
        std::is_same_v<discretization_category FDAPDE_COMMA iso_tag>, TEST_AND_TRIAL_SPACE_MUST_HAVE_THE_SAME_DISCRETIZATION_CATEGORY);
    static constexpr int local_dim = Base::local_dim;
    static constexpr int embed_dim = Base::embed_dim;
    using Base::form_;
    using Base::test_space_;
    // private data members
    const DofHandlerType* trial_dof_handler_;
    constexpr const DofHandlerType* test_dof_handler() const { return Base::dof_handler_; }
    constexpr const DofHandlerType* trial_dof_handler() const {
        return is_galerkin ? Base::dof_handler_ : trial_dof_handler_;
    }
    const TrialSpace* trial_space_;

    public:
    iso_bilinear_form_assembly_loop() = default;
    
    iso_bilinear_form_assembly_loop(
        const Form_& form, typename Base::geo_iterator begin, typename Base::geo_iterator end, const Quadrature_&... quadrature)
        requires(sizeof...(quadrature)<=1) 
        : Base(form, begin, end, quadrature...), trial_space_(std::addressof(internals::trial_space(form_))){
            // print begin cell id
            std::cout<<"ciaooo Begin cell id: "<<begin->id()<<std::endl;
            std::cout<<"ciaoo End cell id: "<<end->id()<<std::endl;
            if constexpr(is_petrov_galerkin){
                trial_dof_handler_ = std::addressof(internals::trial_space(form_).dof_handler());
            }
            fdapde_assert(test_dof_handler()->n_dofs() != 0 && trial_dof_handler()->n_dofs() != 0);

            if constexpr (sizeof...(Quadrature_) == 0) {
                // default to higher-order quadrature
                /*
                if (test_space_->order() != trial_space_->order()) {
                    internals::get_iso_quadrature(
                    test_space_->order() > trial_space_->order() ? test_space_->order() : trial_space_->order(),
                    Base::quad_nodes_, Base::quad_weights_);
                }
                */
            }
    }


    Eigen::SparseMatrix<double> assemble() const {
        std::cout << "MATRIX prima..." << std::endl;
        Eigen::SparseMatrix<double> assembled_mat(test_dof_handler()->n_dofs(), trial_dof_handler()->n_dofs());
        std::cout << "MATRIX dopo..." << std::endl;
        std::vector<Eigen::Triplet<double>> triplet_list;
        std::cout << "Assembling bilinear form..." << std::endl;
        assemble(triplet_list);
        std::cout << "Assembling bilinear form done." << std::endl;
        // linearity of the integral is implicitly used here, as duplicated triplets are summed up (see Eigen docs)
        assembled_mat.setFromTriplets(triplet_list.begin(), triplet_list.end());
        assembled_mat.makeCompressed();
        return assembled_mat;
    }


    void assemble(std::vector<Eigen::Triplet<double>>& triplet_list) const{
        using iterator = typename Base::dof_iterator;
        iterator begin(Base::begin_.index(), test_dof_handler(), Base::begin_.marker());
        iterator end  (Base::end_.index()  , test_dof_handler(), Base::end_.marker());

        // prepare assembly loop
        std::vector<int> test_active_dofs, trial_active_dofs;
        int q = Base::n_quadrature_nodes_;
        int n1 = 1, n2 = 1;

        for(int i = 0; i<local_dim; i++){
            n1*= (test_space_->order())[i] + 1;
            n2*= (is_galerkin ? (test_space_->order())[i] : (trial_space_->order())[i]) + 1;
        }

        MdArray<double, MdExtents<Dynamic, Dynamic>> test_param_shape_values(n1,q), trial_param_shape_values(n2, q);
        MdArray<double, MdExtents<Dynamic, Dynamic, Dynamic>> 
            test_param_shape_grads(n1, q, local_dim), trial_param_shape_grads(n2, q, local_dim);
        MdArray<double, MdExtents<Dynamic, Dynamic, Dynamic, Dynamic>> 
            test_param_shape_hess(n1, q, local_dim, local_dim), trial_param_shape_hess(n2, q, local_dim, local_dim);

        MdArray<Eigen::Matrix<double, embed_dim, local_dim> , MdExtents< Dynamic>> 
            param_grad(q);
        
        MdArray<double, MdExtents<Dynamic>> metric_dets(q);
        

        // distribute quadrature nodes on physical mesh (if required) ..... da capire
        std::cout << "Distributing quadrature nodes..." << std::endl;

        // start assembly loop
        internals::iso_assembler_packet<embed_dim> iso_packet {};
        std::cout << "Assembling cells..." << std::endl;
        int local_cell_id = 0;
        for(iterator it = begin; it!= end; ++it) {
            std::cout << "Assembling cell " << it->id() << std::endl;
            test_active_dofs = it->dofs();
            std::cout << "Test active dofs: ";
            for(auto dof : test_active_dofs) std::cout<<dof<<", ";
            std::cout << std::endl;
            if constexpr (is_petrov_galerkin) { trial_active_dofs = trial_dof_handler()->active_dofs(it->id()); }
            // update the iso_packet
            iso_packet.cell_measure = it->parametric_measure();
            std::cout << "Cell measure: " << iso_packet.cell_measure << std::endl;

            if constexpr (Form::XprBits & int(iso_assembler_flags::compute_shape_values)) {
                std::cout<<"Computing values..."<<std::endl;
                Base::eval_param_shape_values(test_space_->basis(), test_active_dofs, it, test_param_shape_values);
                Base::eval_param_shape_values(
                    trial_space_->basis(), is_petrov_galerkin ? trial_active_dofs : test_active_dofs, it,
                    trial_param_shape_values);
            }
            if constexpr (Form::XprBits & int(iso_assembler_flags::compute_shape_grad)) {
                std::cout<<"Computing grads..."<<std::endl;
                Base::eval_param_shape_grads(test_space_->basis(), test_active_dofs, it, test_param_shape_grads);
                Base::eval_param_shape_grads(
                  trial_space_->basis(), is_petrov_galerkin ? trial_active_dofs : test_active_dofs, it, trial_param_shape_grads);
                
            }
            if constexpr (Form::XprBits & int(iso_assembler_flags::compute_shape_hess)) { //Form::XprBits &
                std::cout<<"Computing hessians..."<<std::endl;
                Base::eval_param_shape_hess(test_space_->basis(), test_active_dofs, it, test_param_shape_hess);
                Base::eval_param_shape_hess(
                  trial_space_->basis(), is_petrov_galerkin ? trial_active_dofs : test_active_dofs, it,
                  trial_param_shape_hess);
            }

            Base::eval_param_grad(it, param_grad); // F
            Base::eval_metric_determinant(it, metric_dets); // metric det(F^T F)
            
            // precompute F(F^T F)^-1 for each q_k
            MdArray<Eigen::Matrix<double, embed_dim, local_dim> , MdExtents< Dynamic>> grad_transf(q);
            for (int q_k = 0; q_k < Base::n_quadrature_nodes_; ++q_k) {
                grad_transf(q_k) = param_grad(q_k) * (param_grad(q_k).transpose() * param_grad(q_k)).inverse();
            }
            std::cout << "Grad transf: " << grad_transf(0).rows() << " x " << grad_transf(0).cols() << std::endl;
            // print Form::XprBits
            //std::cout << "Form::XprBits = 0x" << std::hex << Form::XprBits << std::endl;
            //std::cout << "compute_shape_hess = 0x" << std::hex << int(fdapde::iso_assembler_flags::compute_shape_hess) << std::endl;

            // perform integration of weak form for (i,j)-th basis pair
            for(int i = 0; i<n2; ++i){
                for(int j = 0; j<n1; ++j){
                    double value = 0;
                    //std::cout<<"i = "<<i<<std::endl;
                    //std::cout<<"j = "<<j<<std::endl;
                    for (int q_k = 0; q_k < Base::n_quadrature_nodes_; ++q_k) {
                        if constexpr (Form::XprBits & int(iso_assembler_flags::compute_shape_values)) {
                            iso_packet.trial_value = trial_param_shape_values(i, q_k) ;
                            iso_packet.test_value  = test_param_shape_values (j, q_k) ;
                        }
                        if constexpr (Form::XprBits & int(iso_assembler_flags::compute_shape_grad)) {
                            auto temp_trial_grad = trial_param_shape_grads.template slice<0,1>(i, q_k); 
                            auto temp_test_grad  = test_param_shape_grads.template slice<0,1>(j, q_k);

                            //iso_packet.param_grad = param_grad(q_k);
                            // convert to eigen matrix
                            Eigen::Matrix<double, local_dim, 1> trial_grad, test_grad;

                            for(int k = 0; k < local_dim; ++k) {
                                trial_grad(k) =  temp_trial_grad(k);
                                test_grad(k)  = temp_test_grad(k);
                            }
                            // convert to physical gradient
                            // print the dimensions of grad_transf(q_k)
                            //std::cout << "Grad transf: " << grad_transf(q_k).rows() << " x " << grad_transf(q_k).cols() << std::endl;
                            Eigen::Matrix<double, 3, 1> phys_trial_grad = grad_transf(q_k) *  trial_grad;
                            Eigen::Matrix<double, 3, 1> phys_test_grad  = grad_transf(q_k) * test_grad;
                            std::cout << "Trial grad: " << i <<": "<< phys_trial_grad.transpose() << std::endl;

                            // assign to iso_packet
                            //iso_packet.trial_grad.resize(embed_dim);
                            //iso_packet.test_grad.resize(embed_dim);
                            for(int k = 0; k < embed_dim; ++k) {
                                iso_packet.trial_grad(k) = phys_trial_grad(k);
                                iso_packet.test_grad(k)  = phys_test_grad(k);
                            }
                            std::cout << "Test grad: "<< j <<": " << phys_test_grad.transpose() << std::endl;

                        }
                        if constexpr (Form::XprBits & int(iso_assembler_flags::compute_shape_hess)) { //Form::XprBits &
                            auto param_trial_hess = trial_param_shape_hess.template slice<0,1>(i, q_k);
                            auto param_test_hess  = test_param_shape_hess.template slice<0,1>(j, q_k); // no hessian for no


                            Eigen::Matrix<double, local_dim, local_dim> trial_hess, test_hess;

                            for(int k = 0; k < local_dim; ++k) {
                                for(int l = 0; l < local_dim; ++l) {
                                    trial_hess(k,l) = param_trial_hess(k,l);
                                    test_hess(k,l)  = param_test_hess(k,l);
                                }
                            }
                            // convert to physical gradient
                            auto phys_trial_hess = grad_transf(q_k) * trial_hess * grad_transf(q_k).transpose();
                            auto phys_test_hess  = grad_transf(q_k) * test_hess  * grad_transf(q_k).transpose();
                            // assign to iso_packet
                            //iso_packet.trial_hess.resize(embed_dim, embed_dim);
                            //iso_packet.test_hess.resize(embed_dim, embed_dim);
                            for(int k = 0; k < embed_dim; ++k) {
                                for(int l = 0; l < embed_dim; ++l) {
                                    iso_packet.trial_hess(k,l) = phys_trial_hess(k,l);
                                    iso_packet.test_hess(k,l)  = phys_test_hess(k,l);
                                }
                            }
                        }
                        if constexpr (Form::XprBits & int(iso_assembler_flags::compute_physical_quad_nodes)) {
                            iso_packet.quad_node_id = local_cell_id * Base::n_quadrature_nodes_ + q_k;
                        }
                        value += Base::quad_weights_(q_k, 0) * form_(iso_packet) * metric_dets(q_k);
                    }
                    triplet_list.emplace_back(
                        test_active_dofs[j], is_galerkin ? test_active_dofs[i] : trial_active_dofs[i],
                        value * iso_packet.cell_measure);

                }   

            }
            local_cell_id++;
        }
        return;

    }

    constexpr int n_dofs() const { return trial_dof_handler()->n_dofs(); }
    constexpr int rows() const { return test_dof_handler()->n_dofs(); }
    constexpr int cols() const { return trial_dof_handler()->n_dofs(); }
    constexpr const TrialSpace& trial_space() const { return *trial_space_; } 
    
};



} // namespace internals
} // namespace fdapde

#endif // __FDAPDE_ISO_BILINEAR_FORM_ASSEMBLER_H__